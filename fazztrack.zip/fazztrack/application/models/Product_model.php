<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    private $_table = "produk";

    public $id;
    public $nama_produk;
    public $keterangan;
    public $harga;
    public $jumlah;

    public function rules()
    {
        return [
            ['field' => 'nama_prooduk',
            'label' => 'Nama_produk',
            'rules' => 'required'],

            ['field' => 'keterangan',
            'label' => 'Keterangan',
            'rules' => 'numeric'],
            
            ['field' => 'harga',
            'label' => 'Harga',
            'rules' => 'required'],

            ['field' => 'jumlah',
            'label' => 'Jumlah',
            'rules' => 'required']
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->nama_produk = $post["nama_produk"];
        $this->keterangan = $post["keterangan"];
        $this->harga = $post["harga"];
        $this->jumlah = $post["jumlah"];
        return $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id = uniqid();
        $this->nama_produk = $post["nama_produk"];
        $this->keterangan = $post["keterangan"];
        $this->harga = $post["harga"];
        $this->jumlah = $post["jumlah"];
        return $this->db->update($this->_table, $this, array('id' => $post['id']));
    }

    public function delete($id)
    {
        return $this->db->delete($this->_table, array("id" => $id));
    }
}