<footer class="jumbotron jumbotron-fluid mt-5 mb-0">
    <div class="container text-center">Copyright &copy; <?= Date('Y') ?> CI News</div>
</footer>