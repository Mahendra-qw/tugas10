<header class="jumbotron jumbotron-fluid">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="h1">Portal Berita Codeigniter</h1>
            </div>
        </div>
    </div>
</header>